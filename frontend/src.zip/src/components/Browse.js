import React, { useEffect } from 'react'
import Header from './Header'
import { NOW_PLAYING_URL, OPTIONS } from '../utils/constants';

const Browse = () => {
    const NowPlayingMovies = async () =>{
      const data = await fetch(NOW_PLAYING_URL, OPTIONS)
      const json = await data.json();
      console.log(json)
    } 
  useEffect(()=>{
    NowPlayingMovies()
  },[])
  return (

    <div>
      <Header/>
    </div>
  )
}

export default Browse
